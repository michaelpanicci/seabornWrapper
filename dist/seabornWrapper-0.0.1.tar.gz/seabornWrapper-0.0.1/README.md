# seabornWrapper
Package to wrap seaborn plotting functions to support simple syntax and flexibility with common parameters


Helpful tips for creating a package:
-Create all necessary files: 
PackageName dir 
--->LICENSE, setup.py
--->PackageName dir
    -->__init__.py
    -->functions.py
    -->moreFunctions.py
    -->evenMoreFunctions.py
    
### Install your package locally:
python -m build

##### if 'build' not installed, run pip install build

### upload your project to: https://test.pypi.org/, this is the testing page for PyPi, which stores the necessary code for others to simply "pip install youPackage"

### pip install your package and test it out, if it is good to poductionalize, upload your project to: https://pypi.org/


